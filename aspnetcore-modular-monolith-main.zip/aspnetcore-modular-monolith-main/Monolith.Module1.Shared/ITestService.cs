namespace Monolith.Module1.Shared
{
    public interface ITestService
    {
        string SayHello();
    }
}