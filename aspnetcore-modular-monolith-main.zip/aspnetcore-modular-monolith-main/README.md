# Modular Monolith with ASP.NET Core

Example of a modular monolith with ASP.NET Core.